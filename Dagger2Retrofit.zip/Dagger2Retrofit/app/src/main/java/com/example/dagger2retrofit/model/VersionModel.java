package com.example.dagger2retrofit.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VersionModel {

    @SerializedName("response")
    @Expose
    private VersionResponse response;

    public VersionResponse getResponse() {
        return response;
    }

    public void setResponse(VersionResponse response) {
        this.response = response;
    }

}
