package com.example.dagger2retrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

import android.os.Bundle;
import android.widget.TextView;

import com.example.dagger2retrofit.remote.Repository;
import com.example.dagger2retrofit.viewmodel.ViewModelOne;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Repository repository;
    ViewModelOne viewModelOne;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=(TextView)findViewById(R.id.textview);
/*
        repository = new Repository(this);
        repository.getMutableLiveData().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {

                textView.setText("Version is "+s);

            }
        });*/


     viewModelOne = new ViewModelOne(this);
     viewModelOne.getMutableLiveData().observe(this, new Observer<String>() {
         @Override
         public void onChanged(String s) {
             textView.setText("Version is "+s);
         }
     });

    }
}
