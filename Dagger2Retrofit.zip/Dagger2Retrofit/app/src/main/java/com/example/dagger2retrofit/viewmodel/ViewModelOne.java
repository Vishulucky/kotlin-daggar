package com.example.dagger2retrofit.viewmodel;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.dagger2retrofit.remote.Repository;

import javax.inject.Inject;

public class ViewModelOne extends ViewModel {


     Context context;
    private MutableLiveData<String> mutableLiveData;
    private Repository repository;
     @Inject
    public ViewModelOne(Context context) {
        this.context = context;
        repository= new Repository(context);
        mutableLiveData= new MutableLiveData<>();
    }

    public MutableLiveData<String> getMutableLiveData() {

         mutableLiveData=repository.getMutableLiveData();
        return mutableLiveData;
    }
}
