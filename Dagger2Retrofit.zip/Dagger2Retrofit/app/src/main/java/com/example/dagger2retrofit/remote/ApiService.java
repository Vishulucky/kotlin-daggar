package com.example.dagger2retrofit.remote;

import com.example.dagger2retrofit.model.VersionModel;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {

    @GET("api/appversion")
    Call<VersionModel> getAppVersion();

}
