package com.example.dagger2retrofit.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DataVersion {

    @SerializedName("uniqueid")
    @Expose
    private String uniqueid;

    @SerializedName("mobile")
    @Expose
    private String mobile;

    @SerializedName("appversion")
    @Expose
    private String appversion;

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAppversion() {
        return appversion;
    }

    public void setAppversion(String appversion) {
        this.appversion = appversion;
    }
}
