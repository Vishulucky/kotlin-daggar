package com.example.dagger2retrofit.dagger;

import android.app.Application;

public class BaseApplication extends Application {

    private DaggerComponent daggerComponent;


    @Override
    public void onCreate() {
        super.onCreate();

        daggerComponent= DaggerDaggerComponent.builder().appModule(new AppModule(this)).networkModule(new NetworkModule("https://netbact.com")).build();



    }

    public DaggerComponent getDaggerComponent() {
        return daggerComponent;
    }
}
