package com.example.dagger2retrofit.dagger;


import com.example.dagger2retrofit.remote.Repository;

import javax.inject.Singleton;

import dagger.Component;

@Singleton

@Component(modules = {NetworkModule.class,AppModule.class})
public interface DaggerComponent {

 void inject(Repository repository);


}
