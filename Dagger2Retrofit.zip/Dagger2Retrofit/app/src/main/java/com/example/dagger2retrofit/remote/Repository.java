package com.example.dagger2retrofit.remote;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.example.dagger2retrofit.dagger.BaseApplication;
import com.example.dagger2retrofit.model.VersionModel;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Repository  {

    Context context;

    ApiService apiService;
    @Inject
    Retrofit retrofit;
    private MutableLiveData<String> mutableLiveData;
    @Inject
    public Repository(Context context) {
        this.context = context;

        ((BaseApplication)context.getApplicationContext()).getDaggerComponent().inject(this);


    }

    public MutableLiveData<String> getMutableLiveData() {


        mutableLiveData  = new MutableLiveData<>();
        apiService= retrofit.create(ApiService.class);

        apiService.getAppVersion().enqueue(new Callback<VersionModel>() {
            @Override
            public void onResponse(Call<VersionModel> call, Response<VersionModel> response) {

                mutableLiveData.postValue(""+response.body().getResponse().getData().getAppversion());

            }

            @Override
            public void onFailure(Call<VersionModel> call, Throwable t) {

                Log.d("responseerror",""+t.getMessage());
            }
        });


        return mutableLiveData;
    }
}
